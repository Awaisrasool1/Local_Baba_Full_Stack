package utils

var Categories = []struct {
	ID   string
	Name string
}{
	{ID: "1", Name: "All"},
	{ID: "2", Name: "Fast Food"},
	{ID: "3", Name: "Desi"},
	{ID: "4", Name: "Italian"},
}
